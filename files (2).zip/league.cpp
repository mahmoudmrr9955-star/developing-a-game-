#include "league.hpp"
#include <algorithm>

std::vector<std::vector<std::pair<int,int>>> roundRobin(int n) {
    std::vector<int> a(n);
    for (int i = 0; i < n; ++i) a[i] = i;
    std::vector<std::vector<std::pair<int,int>>> rounds;

    for (int r = 0; r < n - 1; ++r) {
        std::vector<std::pair<int,int>> pairing;
        for (int i = 0; i < n / 2; ++i) {
            int home = a[i], away = a[n - 1 - i];
            pairing.push_back((r % 2 == 0) ? std::make_pair(home, away) : std::make_pair(away, home));
        }
        rounds.push_back(pairing);
        // rotate all but the first element
        int last = a[n - 1];
        for (int i = n - 1; i > 1; --i) a[i] = a[i - 1];
        a[1] = last;
    }

    // Second half of the season: same fixtures, home/away reversed.
    std::vector<std::vector<std::pair<int,int>>> secondHalf;
    for (auto& rd : rounds) {
        std::vector<std::pair<int,int>> mirrored;
        for (auto& fx : rd) mirrored.push_back({fx.second, fx.first});
        secondHalf.push_back(mirrored);
    }
    for (auto& rd : secondHalf) rounds.push_back(rd);
    return rounds;
}

void recordResult(StandingsRow& homeRow, StandingsRow& awayRow, int homeGoals, int awayGoals) {
    homeRow.played++; awayRow.played++;
    homeRow.goalsFor += homeGoals; homeRow.goalsAgainst += awayGoals;
    awayRow.goalsFor += awayGoals; awayRow.goalsAgainst += homeGoals;

    if (homeGoals > awayGoals) {
        homeRow.won++; awayRow.lost++; homeRow.points += 3;
        homeRow.form.push_back('W'); awayRow.form.push_back('L');
    } else if (homeGoals < awayGoals) {
        awayRow.won++; homeRow.lost++; awayRow.points += 3;
        homeRow.form.push_back('L'); awayRow.form.push_back('W');
    } else {
        homeRow.draw++; awayRow.draw++; homeRow.points++; awayRow.points++;
        homeRow.form.push_back('D'); awayRow.form.push_back('D');
    }
}

std::vector<StandingsRow> standings(const std::vector<StandingsRow>& table,
                                     const std::vector<std::string>& teamNames) {
    std::vector<StandingsRow> sorted = table;
    std::sort(sorted.begin(), sorted.end(), [&](const StandingsRow& a, const StandingsRow& b) {
        if (a.points != b.points) return a.points > b.points;
        int gdA = a.goalsFor - a.goalsAgainst, gdB = b.goalsFor - b.goalsAgainst;
        if (gdA != gdB) return gdA > gdB;
        if (a.goalsFor != b.goalsFor) return a.goalsFor > b.goalsFor;
        return teamNames[a.idx] < teamNames[b.idx];
    });
    return sorted;
}

void updateRanks(std::vector<StandingsRow>& table, const std::vector<std::string>& teamNames) {
    auto sorted = standings(table, teamNames);
    for (size_t rank = 0; rank < sorted.size(); ++rank) {
        int idx = sorted[rank].idx;
        for (auto& row : table) {
            if (row.idx == idx) {
                row.prevPos = (row.pos == 0) ? (int)rank + 1 : row.pos;
                row.pos = (int)rank + 1;
                break;
            }
        }
    }
}
